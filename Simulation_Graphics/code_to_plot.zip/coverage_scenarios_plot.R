
## Setup
library(plyr)
load('../data/coverage_scenarios_data.RData')

## Confirm that y ranges of 0--3 and 0--60 (scaled to 0--3) will work
CONVERSION_FACTOR <- 30
stopifnot(round_any(max(coverage_scenarios_data$incidence_ub), 1, ceiling) <= 3)
stopifnot(round_any(max(coverage_scenarios_data$virally_suppressed_pct), CONVERSION_FACTOR, ceiling) <= 60)

plot_coverage_scenarios_for <- function(x) {

    ## Get this country's data
    data <- subset(coverage_scenarios_data, country %in% x)

    ## Set graphical parameters
    par(
        mar=c(0.8, 0.8, 1.5, 0.8),               # Conservative margins c(0.8, 1, 1.5, 0)
        cex=1,                                   # Base font is 10pt (The 'layout' function shrinks the font; this fixes that.)
        cex.main=1, font.main=1,                 # Title is 10pt, regular
        las=1, cex.axis=0.7, col.axis='#4C4C4C', # Axis labels are 7pt, dark gray, and always horizontal
        lend=1
    )

    ## Initialize plot (without actually plotting anything)
    plot(
        x=range(coverage_scenarios_data$coverage) + c(-6, 6),
        y=c(0, 3),
        type='n', ann=FALSE, axes=FALSE
    )

    ## Add titles
    title(toupper(x))

    ## Draw background rectangle
    rect(par()[['usr']][1], par()[['usr']][3], par()[['usr']][2], par()[['usr']][4], col='#ECECEC', border=NA)

    ## Add gridlines
    x_ticks <- sort(unique(coverage_scenarios_data$coverage))
    y_ticks <- seq(0, 100, 1)
    abline(h=y_ticks, col='#FFFFFF', lwd=0.5)

    ## Add legend
    if (x == 'Uganda') {
        legend(
            x='topleft', inset=0,
            bg='#ECECEC', box.col='#ECECEC',
            legend=c('Incidence', 'Viral suppression'),
            cex=0.8, text.col='#4C4C4C',
            lwd=c(1.25, 8), col=c('#4C4C4Cbb', '#4A7C01bb'), lty=1, seg.len=1
        )
    }

    ## Label axes
    if (x == 'South Africa') { axis(1, at=x_ticks, labels=round(x_ticks), tick=FALSE, mgp=c(0, 0, -0.1)) }
    axis(2, at=y_ticks, tick=FALSE, mgp=c(0, 0, 0.2))
    axis(4, at=y_ticks, labels=CONVERSION_FACTOR*y_ticks, tick=FALSE, mgp=c(0, 0, 0.2))

    ## Draw bars
    for (i in seq(nrow(data))) {
        coverage <- data$coverage[i]
        virally_suppressed_pct <- data$virally_suppressed_pct[i]
        rect(
            coverage - 6,
            0,
            coverage + 6,
            virally_suppressed_pct/CONVERSION_FACTOR,
            col='#4A7C01bb',
            border=NA
        )
        text(coverage, virally_suppressed_pct/CONVERSION_FACTOR, paste0(round(virally_suppressed_pct), '%'), cex=0.8, col='#4C4C4C', pos=3, offset=0.2)
        rm(coverage, virally_suppressed_pct)
    }
    rm(i)

    ## Draw lines
    with(data, mapply(
        function(x, y1, y2) {
            lines(c(x, x), c(y1, y2), lwd=1.25, col='#4C4C4Caa')
        },
        coverage,
        incidence_lb,
        incidence_ub
    ))
    lines(data$coverage, data$incidence, lwd=2, col='#4C4C4Cbb')
}



###
### PLOT
###

## Initialize graphics device and define layout
graphics.off()
pdf('../out/coverage_scenarios_plot.pdf', width=2.975, height=(5/4)*2.975, pointsize=10)
layout(matrix(c(2, 2, 0, 4, 5, 1, 3, 3, 0), ncol=3), widths=c(lcm(0.75), 1, lcm(0.75)), heights=c(1, 1, lcm(0.75)))

## Label the x-axis
par(mar=c(0, 0.8, 0, 0.8), cex=1)
plot(c(-1:1), c(-1:1), type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'Coverage (%)', cex=1.1)

## Label the y-axes
par(mar=c(0.8, 0, 1.5, 0), cex=1)
plot(c(-1:1), c(-1:1), type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'HIV incidence (per 100 person-years)', srt=90, cex=1.1)

par(mar=c(0.8, 0, 1.5, 0), cex=1)
plot(c(-1:1), c(-1:1), type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'Percent virally suppressed at year 10', srt=-90, cex=1.1)

## Plot data
plot_coverage_scenarios_for('Uganda')
plot_coverage_scenarios_for('South Africa')

graphics.off()
