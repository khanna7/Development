
###
### SETUP
###

library(plyr)

load('../data/hiv_incidence.RData')

## Define a function to plot the data for a given country (x) and scenario (y)
plot_incidence_for <- function(x, y) {

    ## Set graphical parameters
    par(
        mar=c(0.9, 0.6, 2.25, 0),                     # Conservative margins
        cex=1,                                        # Base font is 10pt (The 'layout' function shrinks the font; this fixes that.)
        cex.main=1, font.main=1,                      # Title is 10pt, regular
        las=1, cex.axis=0.7, col.axis='#4C4C4C'       # Axis labels are 7pt, dark gray, and always horizontal
    )

    ## Initialize plot (without actually plotting anything)
    plot(
        x=range(hiv_incidence$year) + c(0, 0.2),
        y=c(0, round_any(max(hiv_incidence$incidence), 1, ceiling)),
        type='n', ann=FALSE, axes=FALSE
    )

    ## Add titles
    if (y == 'Best PMTCT') { title(toupper(x), line=1.25) }
    title(toupper(y), cex.main=0.7, col.main='#4C4C4C', line=0.25)

    ## Draw background rectangle
    rect(par()[['usr']][1], par()[['usr']][3], par()[['usr']][2], par()[['usr']][4], col='#ECECEC', border=NA)

    ## Add gridlines
    x_ticks <- seq(0, 100, 2)
    y_ticks <- seq(0, 100, 1)
    abline(v=x_ticks, h=y_ticks, col='#FFFFFF', lwd=0.5, lend=1)

    ## Add legend
    if (x == 'Uganda' & y == 'Best ART & PMTCT') {
        legend(
            x='topright', inset=0,
            bg='#ECECEC', box.col='#ECECEC',
            legend=paste('Option', levels(hiv_incidence$pmtct_intervention)),
            cex=0.8, text.col='#4C4C4C',
            lwd=2, col=c('#0046ADbb', '#C75B12bb', '#4A7C01bb'), lty=1:3
        )
    }

    ## Label axes
    if (x == 'South Africa') { axis(1, at=x_ticks, tick=FALSE, mgp=c(0, 0, -0.1)) }
    if (y == 'Current') { axis(2, at=y_ticks, tick=FALSE, mgp=c(0, 0, 0.2)) }

    ## Finally, draw lines
    for (i in seq(along=levels(hiv_incidence$pmtct_intervention))) {
        data <- subset(hiv_incidence, country %in% x & scenario %in% y & pmtct_intervention %in% levels(pmtct_intervention)[i])
        color <- c('#0046ADbb', '#C75B12bb', '#4A7C01bb')[i]
        with(subset(data, year %in% seq(2, 10, by=2)), mapply(
            function(x, y1, y2) {
                lines(c(x, x), c(y1, y2), lwd=1.25, col=sub('..$', 'aa', color), lend=1)
            },
            year + c(-0.2, 0, 0.2)[i],
            lb,
            ub
        ))
        with(data, lines(year, incidence, lwd=2, col=color, lty=i))
        rm(data, color)
    }
    rm(i)
}

## Define a function to "plot" a table cell
tabulate_incidence_for <- function(x, y) {
    data <- subset(hiv_incidence, country %in% x & scenario %in% y & year %in% 10)
    stopifnot(all(data$pmtct_intervention == c('A', 'B', 'B+')))

    string <- apply(
        data[, c('incidence', 'lb', 'ub')],
        1,
        function(x) {
            sprintf('%.2f (%.2f\u2013%.2f)', x['incidence'], x['lb'], x['ub'])
        }
    )

    par(mar=c(0, 0.6, 0, 0), cex=1)
    plot(c(-1, 1), c(-1.5, 1.5), xaxs='i', yaxs='i', type='n', axes=FALSE, ann=FALSE)
    text(c(0, 0, 0), c(1, 0, -1), string, cex=0.8, adj=c(0.5, 0.5))
}



###
### PLOT
###

## Initialize graphics device and define layout
graphics.off()
pdf('../out/hiv_incidence_plot.pdf', width=6.10, height=6.10, pointsize=10)
layout(
    matrix(ncol=5, byrow=TRUE,
        c(
             1,  3,  4,  5,  0, # Y-axis title; Uganda plots
             1,  6,  7,  8,  0, # Y-axis title; South Africa plots
             0,  2,  2,  2,  0, # X-axis title
             9,  9,  9,  9,  0, # toprule
            11, 11, 11, 11,  0, # Heading
             0, 13, 15, 17,  0, # Subheading
            19, 21, 22, 23,  0, # Row heading; Data
             0,  0,  0,  0,  0, # Blank row
            12, 12, 12, 12,  0, # Heading
             0, 14, 16, 18,  0, # Subheading
            20, 24, 25, 26,  0, # Row heading; Data
            10, 10, 10, 10,  0  # bottomrule
        )
    ),
    widths=c(lcm(0.75), 1, 1, 1, lcm(0.2)),
    heights=c(
        1, 1, lcm(0.75),
        # lcm(0.25), lcm(0.75), lcm(0.5), lcm(1.5), lcm(0.25), lcm(0.75), lcm(0.5), lcm(1.5), lcm(0.25)
        sapply((2.54*(6.10 - (2/3)*6.10) / sum(c(rep(c(1, 2, 2, 7), 2), 1))) * c(rep(c(1, 2, 2, 7), 2), 1), lcm)
    )
)

## Label the y-axis
par(mar=c(0.9, 0, 2.25, 0), cex=1)
plot(c(-1:1), c(-1:1), type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'HIV incidence (per 100 person-years)', srt=90, cex=1.1)

## Label the x-axis
par(mar=c(0, 0.6, 0, 0), cex=1)
plot(c(-1:1), c(-1:1), type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'Intervention year', cex=1.1)

## Plot data
plot_incidence_for('Uganda', 'Current')
plot_incidence_for('Uganda', 'Best PMTCT')
plot_incidence_for('Uganda', 'Best ART & PMTCT')
plot_incidence_for('South Africa', 'Current')
plot_incidence_for('South Africa', 'Best PMTCT')
plot_incidence_for('South Africa', 'Best ART & PMTCT')

## Toprule/bottomrule
par(mai=c(0, 0.0787402, 0, 0))
plot(c(-1:1), c(-1:1), xaxs='i', type='n', axes=FALSE, ann=FALSE)
lines(c(-1, 1), c(0, 0), lwd=1.25)

par(mai=c(0, 0.0787402, 0, 0))
plot(c(-1:1), c(-1:1), xaxs='i', type='n', axes=FALSE, ann=FALSE)
lines(c(-1, 1), c(0, 0), lwd=1.25)

## Heading
par(mar=c(0, 0.6, 0, 0), cex=1)
plot(c(-1:1), c(-1:1), xaxs='i', type='n', axes=FALSE, ann=FALSE)
text(-1, 0, 'UGANDA: INCIDENCE AT YEAR 10', adj=c(0, 0.5), cex=0.8, font=2)

par(mar=c(0, 0.6, 0, 0), cex=1)
plot(c(-1:1), c(-1:1), xaxs='i', type='n', axes=FALSE, ann=FALSE)
text(-1, 0, 'SOUTH AFRICA: INCIDENCE AT YEAR 10', adj=c(0, 0.5), cex=0.8, font=2)

## Subheading
par(mar=c(0, 0.6, 0, 0), cex=1)
plot(c(-1:1), c(-1:1), xaxs='i', type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'CURRENT', cex=0.7)
lines(c(-1, 1), c(-1, -1), lwd=0.5)

par(mar=c(0, 0.6, 0, 0), cex=1)
plot(c(-1:1), c(-1:1), xaxs='i', type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'CURRENT', cex=0.7)
lines(c(-1, 1), c(-1, -1), lwd=0.5)

par(mar=c(0, 0.6, 0, 0), cex=1)
plot(c(-1:1), c(-1:1), xaxs='i', type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'BEST PMTCT', cex=0.7)
lines(c(-1, 1), c(-1, -1), lwd=0.5)

par(mar=c(0, 0.6, 0, 0), cex=1)
plot(c(-1:1), c(-1:1), xaxs='i', type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'BEST PMTCT', cex=0.7)
lines(c(-1, 1), c(-1, -1), lwd=0.5)

par(mar=c(0, 0.6, 0, 0), cex=1)
plot(c(-1:1), c(-1:1), xaxs='i', type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'BEST ART & PMTCT', cex=0.7)
lines(c(-1, 1), c(-1, -1), lwd=0.5)

par(mar=c(0, 0.6, 0, 0), cex=1)
plot(c(-1:1), c(-1:1), xaxs='i', type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'BEST ART & PMTCT', cex=0.7)
lines(c(-1, 1), c(-1, -1), lwd=0.5)

## Row headings
par(mar=c(0, 0.95, 0, 0), cex=1)
plot(c(0, 1), c(-1.5, 1.5), xaxs='i', yaxs='i', type='n', axes=FALSE, ann=FALSE)
text(c(0, 0, 0), c(1, 0, -1), c('A', 'B', 'B+'), cex=0.8, adj=c(0, 0.5))

par(mar=c(0, 0.95, 0, 0), cex=1)
plot(c(0, 1), c(-1.5, 1.5), xaxs='i', yaxs='i', type='n', axes=FALSE, ann=FALSE)
text(c(0, 0, 0), c(1, 0, -1), c('A', 'B', 'B+'), cex=0.8, adj=c(0, 0.5))

## Data
tabulate_incidence_for('Uganda', 'Current')
tabulate_incidence_for('Uganda', 'Best PMTCT')
tabulate_incidence_for('Uganda', 'Best ART & PMTCT')
tabulate_incidence_for('South Africa', 'Current')
tabulate_incidence_for('South Africa', 'Best PMTCT')
tabulate_incidence_for('South Africa', 'Best ART & PMTCT')

graphics.off()
