
###
### SETUP
###

library(plyr)

load('../data/hiv_prevalence.RData')

## Define a function to plot the data for a given country
plot_prevalence_for <- function(x) {

    ## Set graphical parameters
    par(
        mar=c(0.8, 1, 1.5, 0),                        # Conservative margins
        cex=1,                                        # Base font is 10pt (The 'layout' function shrinks the font; this fixes that.)
        cex.main=1, font.main=1,                      # Title is 10pt, regular
        las=1, cex.axis=0.7, col.axis='#4C4C4C'       # Axis labels are 7pt, dark gray, and always horizontal
    )

    ## Initialize plot (without actually plotting anything)
    plot(
        x=range(hiv_prevalence$year),
        y=c(0, round_any(max(hiv_prevalence$prevalence), 0.1, ceiling)),
        type='n', ann=FALSE, axes=FALSE
    )

    ## Add a title
    title(toupper(x))

    ## Draw background rectangle
    rect(par()[['usr']][1], par()[['usr']][3], par()[['usr']][2], par()[['usr']][4], col='#ECECEC', border=NA)

    ## Add gridlines
    x_ticks <- seq(0, 100, 10)
    y_ticks <- seq(0, 1, 0.1)
    abline(v=x_ticks, h=y_ticks, col='#FFFFFF', lwd=0.5, lend=1)

    ## Label axes
    if (x == 'South Africa') { axis(1, at=x_ticks, labels=x_ticks, tick=FALSE, mgp=c(0, 0, -0.1)) }
    axis(2, at=y_ticks, labels=round(100*y_ticks), tick=FALSE, mgp=c(0, 0, 0.2))

    ## Add calibration points
    if (x == 'Uganda') {
        points(38, 10.667/100, pch=20, cex=1.5, col='#B50014bb')
        text(38, 10.667/100, '10.7% in 2012\n(Jain 2014)\n', adj=c(1, 0), offset=1, cex=0.8, col='#B50014')
    }

    if (x == 'South Africa') {
        points(28, 25.8/100, pch=20, cex=1.5, col='#B50014bb')
        text(28, 25.8/100, '\n25.8% in 2008\n(Shisana 2009)', adj=c(1, 1), offset=1, cex=0.8, col='#B50014')
    }

    ## Finally, draw lines
    with(subset(hiv_prevalence, country %in% x),
        lines(year, prevalence, lwd=2, col='#4C4C4Cbb')
    )
}



###
### PLOT
###

## Initialize graphics device and define layout
graphics.off()
pdf('../out/hiv_prevalence_plot.pdf', width=2.975, height=2.975, pointsize=10)
layout(matrix(c(1, 1, 0, 3, 4, 2, 0, 0, 0), ncol=3), widths=c(lcm(0.75), 1, lcm(0.2)), heights=c(1, 1, lcm(0.75)))

## Label the y-axis
par(mar=c(0.8, 0, 1.5, 0), cex=1)
plot(c(-1:1), c(-1:1), type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'HIV prevalence (%)', srt=90, cex=1.1)

## Label the x-axis
par(mar=c(0, 1, 0, 0), cex=1)
plot(c(-1:1), c(-1:1), type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'Burn-in (years)', cex=1.1)

## Plot data
plot_prevalence_for('Uganda')
plot_prevalence_for('South Africa')

graphics.off()
