
###
### SETUP
###

library(plyr)

load('../data/viral_suppression.RData')

## Define a function to plot the data for a given country (x) and scenario (y)
plot_incidence_for <- function(x, y) {

    ## Set graphical parameters
    par(
        mar=c(0.9, 0.6, 2.25, 0),                     # Conservative margins
        cex=1,                                        # Base font is 10pt (The 'layout' function shrinks the font; this fixes that.)
        cex.main=1, font.main=1,                      # Title is 10pt, regular
        las=1, cex.axis=0.7, col.axis='#4C4C4C'       # Axis labels are 7pt, dark gray, and always horizontal
    )

    ## Initialize plot (without actually plotting anything)
    plot(
        x=c(0.4, 3.6), xaxs='i',
        y=c(0, round_any(max(viral_suppression$virally_suppressed_pct), 5, ceiling) + 5),
        type='n', ann=FALSE, axes=FALSE
    )

    ## Add titles
    if (y == 'Best PMTCT') { title(toupper(x), line=1.25) }
    title(toupper(y), cex.main=0.7, col.main='#4C4C4C', line=0.25)

    ## Draw background rectangle
    rect(par()[['usr']][1], par()[['usr']][3], par()[['usr']][2], par()[['usr']][4], col='#ECECEC', border=NA)

    ## Add gridlines
    y_ticks <- seq(0, 100, 20)
    abline(h=y_ticks, col='#FFFFFF', lwd=0.5, lend=1)

    ## Label axes
    if (x == 'South Africa') { axis(1, at=1:3, labels=levels(viral_suppression$pmtct_intervention), tick=FALSE, mgp=c(0, 0, -0.1)) }
    if (y == 'Current') { axis(2, at=y_ticks, tick=FALSE, mgp=c(0, 0, 0.2)) }

    ## Finally, draw boxes
    for (i in seq(along=levels(viral_suppression$pmtct_intervention))) {
        virally_suppressed_pct <- viral_suppression$virally_suppressed_pct[
            with(viral_suppression, country %in% x & scenario %in% y & pmtct_intervention %in% levels(pmtct_intervention)[i])
        ]
        stopifnot(length(virally_suppressed_pct) == 1)
        rect(
            i - 0.4, 0, i + 0.4, virally_suppressed_pct,
            col=c('#0046ADbb', '#C75B12bb', '#4A7C01bb')[i], border=NA
        )
        text(i, virally_suppressed_pct, paste0(round(virally_suppressed_pct), '%'), cex=0.8, col='#4C4C4C', pos=3, offset=0.2)
        rm(virally_suppressed_pct)
    }
    rm(i)
}



###
### PLOT
###

## Initialize graphics device and define layout
graphics.off()
pdf('../out/viral_suppression_plot.pdf', width=6.10, height=(2/3)*6.10, pointsize=10)
layout(matrix(c(1, 1, 0, 3, 6, 2, 4, 7, 2, 5, 8, 2, 0, 0, 0), ncol=5), widths=c(lcm(0.75), 1, 1, 1, lcm(0.2)), heights=c(1, 1, lcm(0.75)))

## Label the y-axis
par(mar=c(0.9, 0, 2.25, 0), cex=1)
plot(c(-1:1), c(-1:1), type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'Percent virally suppressed at year 10', srt=90, cex=1.1)

## Label the x-axis
par(mar=c(0, 0.6, 0, 0), cex=1)
plot(c(-1:1), c(-1:1), type='n', axes=FALSE, ann=FALSE)
text(0, 0, 'PMTCT intervention', cex=1.1)

## Plot data
plot_incidence_for('Uganda', 'Current')
plot_incidence_for('Uganda', 'Best PMTCT')
plot_incidence_for('Uganda', 'Best ART & PMTCT')
plot_incidence_for('South Africa', 'Current')
plot_incidence_for('South Africa', 'Best PMTCT')
plot_incidence_for('South Africa', 'Best ART & PMTCT')

graphics.off()
